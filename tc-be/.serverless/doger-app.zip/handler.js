import handler from 'serverless-express/handler'

import app from './index'

module.exports = handler(app)
